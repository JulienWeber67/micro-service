class commantaireserialisation (serialisation):
    class meta :
        model:commantaire
        fields = ['titre','commantaire','date']
def post (self,request,*args,**kwargs):
    data = {'titre':request.data.get('titre'),'commantaire':request.data.get('commantaire'),'cdate':request.data.get('cdate')}
    serializer = commmantaireserializer(dtata=data)
    if serializer.is_valid():
        serializer.save()
        return response (serializer.data,status=status.HTTP_201_created)
    return response ({'res:''error'},status=status.HTTP_400_BAD_REQUEST) 