from 



urlpatterns = [
 path ('api/',commentlistAPIview.as_view())   
]