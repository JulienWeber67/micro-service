from django.db import models

class commantaireDetailAPIview (APIview): 
    def get (self,request,id,*args,**kargs):
        comment = commantaire.objects.get(id=id)
        if comment is None :
            return response({"res":"objectnotfound"}, status=status.HTTP_400_BAD.REQUEST)
        serializer = commentserializer(comment)
        return response(serializer,data,status=status.HTTP_200_OK)
    
    def delete (self,request,id):
        comment = commantaire.objects.get(id=id)
        if comment is None :
            return response({"res","notfound"},status=status.HTTP_404_NOTFOUND)
        comment.delete()
        return response({"res","objectdeleted"},status=status.HTTP_200_OK)

titre=
commantaire=
cdate=