from django.shortcuts import render
from .models import commantaire
from rest_framework.views import APIview
from rest_framework.response import response
from rest_framework import status


class commentlistAPIview(APIview):
    def get (self,request,*args,**kwargs):
        clist=commantaire.objects.all()
        serializer = commantaire.serializer (clist,many = True)
        return response(serializer.data,status = status.HTTP_200_ok)
    def post (self,request,*args,**kwargs):
        clist=commantaire.objects.all ()
        serializer = commantaire.serializer(clist,many = False)
        return response(serializer.data,status = status.HTTP_201_ok)

class commantaireserialisation (serialisation):
    class meta :
        model:commantaire
        fields = ['titre','commantaire','date']
def post (self,request,*args,**kwargs):
    data = {'titre':request.data.get('titre'),'commantaire':request.data.get('commantaire'),'cdate':request.data.get('cdate')}
    serializer = commmantaireserializer(dtata=data)
    if serializer.is_valid():
        serializer.save()
        return response (serializer.data,status=status.HTTP_201_created)
    return response ({'res:''error'},status=status.HTTP_400_BAD_REQUEST) 
